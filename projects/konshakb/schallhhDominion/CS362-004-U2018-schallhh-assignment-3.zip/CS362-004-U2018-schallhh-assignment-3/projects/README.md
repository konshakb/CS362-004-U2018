The projects directory should contain your onid (e.g., aburasa) folder.
Do not use your student ID, please.
